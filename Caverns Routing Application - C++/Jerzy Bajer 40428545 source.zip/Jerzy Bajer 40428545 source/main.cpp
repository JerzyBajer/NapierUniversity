#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
#include <fstream>
#include <conio.h>
#include <math.h>
// author: Jerzy Bajer

using namespace std;

// class for Cavern objects
class Cavern
{
public:
unsigned short x, y;                        // cavern x and y position
unsigned short parent;                      // accessed from parent cavern
bool added;                                 // was cavern added to list
double distance;                            // distance from beginning to this cavern
vector<unsigned short> neighbours;          // all caverns which can be reached from this cavern
};

// loads data from file an put into array of cavern
Cavern * loadData(string fileName, int *cavernNumber)
{
fileName.append(".cav");                                        // adds .cav extension
ifstream file(fileName);                                        // file to read from
Cavern *caverns;                                                // local pointer to Cavern array
string line;                                                    // line read from file
string s = "";                                                  // string used to keep chars used for conversion to num
char c;                                                         // used to keep character read from line
unsigned short num = 0;                                         // used for conversion string to short
int i = 0;                                                      // used to keep track during loading data
int numOfXY = 0;                                                // number of x and y values in file,  x and y for each cavern
int pesentCavern = 0;                                           // used to go to next cavern when putting x and y values
int posXY = 0;                                                  // 0 = x position, 1 = y position
int child = 0;                                                  // used to go to next cavern when putting neighbours
int parent = 0;                                                 // used when looping through caverns checking to which cavern exist route from present/parent cavern

for (; getline (file, line);)
{
for(int cNum = 0 ; cNum < line.length(); cNum++ )
{
c = line[cNum];
if(c!=',')
{
s += c;
}
else
{
num = atoi(s.c_str());
s = "";

if(i==0)
{
*cavernNumber = num;
caverns = new Cavern[*cavernNumber];
for(int index=0; index<*cavernNumber; index++)
{
caverns[index].parent = USHRT_MAX;      // USHRT_MAX = 65535
caverns[index].added = 0;
caverns[index].distance = UINT_MAX;     // UINT_MAX = 4294967295
}
numOfXY = 2*(*cavernNumber);
}
else if(i<=numOfXY)
{
if(posXY==0){caverns[pesentCavern].x = num;}
else{ caverns[pesentCavern].y = num;}
posXY++;
if(posXY==2){ posXY=0; pesentCavern++;}
}
else
{
    if(num==1)
    {
    caverns[parent].neighbours.push_back(child);
    }
    parent++;
    if(parent==*cavernNumber)
    {
    child++;
    parent = 0;
    }
}
i++;
}
}
}
file.close();                                               // close file
return caverns;
}

// gets distance
double getDistance(Cavern p, Cavern c,  Cavern caverns[])
{
if(p.parent!=USHRT_MAX){ return getDistance(caverns[p.parent],  p, caverns)+(sqrt(((p.x - c.x)*(p.x - c.x)) + ((p.y - c.y)*(p.y - c.y)))); }
else{ return 0 + (sqrt(((p.x - c.x)*(p.x - c.x)) + ((p.y - c.y)*(p.y - c.y))));}
}

// gets shortest routes between all caverns
void getRoutes(Cavern caverns[])
	{
    vector<unsigned short> all;     // holds number of all caverns to be visited
    all.push_back(0);               // add first cavern to be visited
    caverns[0].distance = 0;        // puts first cavern distance as 0
    caverns[0].added = 1;           // marks first cavern as added

    unsigned short parent;          // keeps number for present cavern in all for which will be checked possible routes
    unsigned short child;           // used when conversing string neighbour to number
    double distance = 0;            // used when calculating distance

    for(int i=0; i<all.size(); i++)
    {
    parent = all[i];                // put current number from all as current parent

    // cout << "Parent: " << parent << endl;
    if(caverns[parent].neighbours.size()>0)
    {
    for(int j=0; j<caverns[parent].neighbours.size(); j++)
    {
    child = caverns[parent].neighbours[j];
    // cout << "Child: " << child << endl;

    if(caverns[child].added==0)         // was not added yet to list
    {
        all.push_back(child);             // if child cavern.visited==0 then add it to all
        caverns[child].added = 1;       // and mark as visited so it does not get added again
        // cout << "Added: " << child << endl;
    }

    if(caverns[child].parent!=USHRT_MAX){ caverns[child].distance = getDistance(caverns[caverns[child].parent], caverns[child], caverns); }
    // cout << "Child: " << caverns[child].distance << endl;
    distance = getDistance(caverns[parent], caverns[child], caverns);    // get distance
    // cout << "New: " << distance << endl;

    if(caverns[child].distance>distance)                            // if distance to child from its parent is bigger than distance from current parent
    {
    caverns[child].distance = distance;                             // update child distance
    // cout << "After: " << caverns[child].distance << endl;
    caverns[child].parent = parent;                                 // change parent to current
    // cout << "After: " << caverns[child].parent << endl;
    }
    }
    caverns[parent].neighbours.clear();
    // cout << "=============================================================================== \n";
    }
    }
    }

// gets solution if it exist and saves it to file
void getSolution(string fileName, Cavern caverns[], int *cavernNumber)
{
    string solution = "";   //Path: ";
    if(caverns[*cavernNumber-1].parent!=USHRT_MAX)                  // if last cavern was reached from another cavern
    {
    vector<unsigned short> path;
    int currentCav = *cavernNumber-1;                               // put last cavern as current
    path.push_back(currentCav+1);                                   // add last cavern+1 to path - in array first cavern is 0 last is N-1

    while(currentCav!=0)
    {
    path.push_back(caverns[currentCav].parent+1);                   // add parent for currentCav to path
    currentCav = caverns[currentCav].parent;                        // put currentCav as its parent
    }
    for(int i= path.size()-1; i>=0 ; i--)                           // swap path
    {
    solution.append( std::to_string(path.at(i)));                   // add each cavern to path
    solution += " ";
    }
    /*
    double distance = round((caverns[*cavernNumber-1].distance)*100)/100;
    string distSt = std::to_string(distance);
    for(int i=0; i<distSt.length(); i++){if(distSt[i]=='.'){ distSt = distSt.substr (0,i+3); }}
    solution.append("\n");
    solution.append(distSt) ;    // add distance to solution
    */
    }
    else                                                           // if not there is no solution
    {
    solution = "0" ;
    }

    fileName.append(".csn");
    ofstream myfile;
    myfile.open (fileName);             // open file
    myfile << solution;                 // save to file
    myfile.close();                     // close file
}

int main(int argc, char* argv[])
{
    Cavern *cavPointer;                                     // pointer to array of cavern objects
    int number = 0;                                         // number of caverns
    int *numPointer = &number;                              // pointer to number of caverns
    if(argc>1)
    {
    string fileName = argv[1];                              // file with caverns
    cavPointer = loadData(fileName, numPointer);            // loads data and put it into array

    /*
    cout << "=====================================================" << endl;
    cout << "Number of caverns: " << *numPointer << endl;
    cout << "=====================================================" << endl;
    for(int i=0; i<*numPointer; i++)
    {
    cout << "Cavern " << i << ", (" << cavPointer[i].x << "," << cavPointer[i].y << ")" << endl;
    cout <<  cavPointer[i].parent << ", " <<  cavPointer[i].added << ", " <<  cavPointer[i].distance << endl;

    for(int j=0; j<cavPointer[i].neighbours.size(); j++)
    {
     cout <<  cavPointer[i].neighbours[j] <<", " << endl;
    }
    cout << "=================================================================" << endl;
    }
    cout << endl << endl;
    */

    if(*numPointer>0)
    {
    getRoutes(cavPointer);
    getSolution(fileName, cavPointer, numPointer);
    }
    }
    return 0;
}



